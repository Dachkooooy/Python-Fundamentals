words = input().split()
new_word = [word * len(word) for word in words]
print(''.join(new_word))