string = input()
substring = ''
final_string = ''
repetitions = ''
for index in range(len(string)):
    # we have non-digit symbol
    if not string[index].isdigit():
        substring += string[index].upper()
    # we have a digit symbol
    else:
        for next_characters in range(index, len(string)):
            if not string[next_characters].isdigit():
                break
            repetitions += string[next_characters]
        final_string += substring * int(repetitions)
        substring = ''
        repetitions = ''

print(f"Unique symbols used: {len(set(final_string))}")
print(final_string)
