def check_ticket(ticket: str) -> str:
    if len(ticket) != 20:
        return "invalid ticket"
    winning_symbols = ('@', '#', '$', '^')
    left_part = ticket[:10]
    right_part = ticket[10:]
    for winning_symbol in winning_symbols:
        for uninterrupted_match_length in range(10, 5, -1):
            winning_symbol_repetition = winning_symbol * uninterrupted_match_length
            # Case where we have a winning symbol
            if winning_symbol_repetition in right_part and winning_symbol_repetition in left_part:
                if uninterrupted_match_length == 10:
                    # Jackpot ticket
                    return f'ticket "{ticket}" - {uninterrupted_match_length}{winning_symbol} Jackpot!'
                # Winning ticket but not Jackpot
                return f'ticket "{ticket}" - {uninterrupted_match_length}{winning_symbol}'
    return f'ticket "{ticket}" - no match'


collection_of_tickets = [ticket.strip() for ticket in input().split(", ")]
for current_ticket in collection_of_tickets:
    print(check_ticket(current_ticket))