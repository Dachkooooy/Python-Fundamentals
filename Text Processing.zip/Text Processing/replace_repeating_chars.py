sequence_of_letters = input()
final_string = ""
last_letter = ""

for character in sequence_of_letters:
    if character != last_letter:
        final_string += character
        last_letter = character
print(final_string)
