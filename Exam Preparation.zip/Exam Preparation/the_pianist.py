number_of_pieces = int(input())
piano = {}

for _ in range(number_of_pieces):
    piano_pieces = input().split("|")
    piece = piano_pieces[0]
    composer = piano_pieces[1]
    key = piano_pieces[2]
    if piece not in piano.keys():
        piano[piece] = {'composer': composer, 'key': key}
    else:
        piano[piece]['composer'] += composer
        piano[piece]['key'] += key

while (command:= input()) != "Stop":
    command = command.split("|")

    if command[0] == "Add":
        piece = command[1]
        composer = command[2]
        key = command[3]
        if piece not in piano.keys():
            piano[piece] = {'composer': composer, 'key': key}
            print(f"{piece} by {composer} in {key} added to the collection!")
        else:
            print(f"{piece} is already in the collection!")

    elif command[0] == "Remove":
        piece = command[1]
        if piece in piano.keys():
            piano.pop(piece)
            print(f"Successfully removed {piece}!")
        else:
            print(f'Invalid operation! {piece} does not exist in the collection.')

    elif command[0] == "ChangeKey":
        piece = command[1]
        new_key = command[2]
        if piece in piano.keys():
            piano[piece]['key'] = new_key
            print(f"Changed the key of {piece} to {new_key}!")
        else:
            print(f"Invalid operation! {piece} does not exist in the collection.")

for pieces, data in piano.items():
    print(f"{pieces} -> Composer: {data['composer']}, Key: {data['key']}")