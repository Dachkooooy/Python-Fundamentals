activation_string = input()

while (command:= input()) != "Generate":
    command = command.split(">>>")

    if command[0] == "Contains":
        substring = command[1]
        if substring in activation_string:
            print(f"{activation_string} contains {substring}")
        else:
            print("Substring not found!")

    elif command[0] == "Flip":
        start_index = int(command[2])
        end_index = int(command[3])
        if command[1] == "Upper":
            activation_string = activation_string[:start_index] + activation_string.upper()[start_index:end_index] + activation_string[end_index:]
            print(activation_string)
        elif command[1] == "Lower":
            activation_string = activation_string[:start_index] + activation_string.lower()[start_index:end_index] + activation_string[end_index:]
            print(activation_string)

    elif command[0] == "Slice":
        start_index = int(command[1])
        end_index = int(command[2])
        activation_string = activation_string[:start_index] + activation_string[end_index:]
        print(activation_string)

print(f"Your activation key is: {activation_string}")