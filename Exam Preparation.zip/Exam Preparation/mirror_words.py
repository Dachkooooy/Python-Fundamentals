import re

text_string = input()
pattern = r"([#@])([A-Za-z]{3,})\1\1([A-Za-z]{3,})\1"
matches = re.finditer(pattern, text_string)
valid_pairs = []
pairs = []

if matches:
    for match in matches:
        pairs.append(match.group(0))
        if match.group(3)[::-1] == match.group(2) or match.group(2)[::-1] == match.group(3):
            valid_pairs.append(match.group(2) + " <=> " + match.group(3))
    if len(pairs) > 0:
        print(f"{len(pairs)} word pairs found!")
    else:
        print("No word pairs found!")

if not valid_pairs:
    print("No mirror words!")
else:
    print("The mirror words are:")
    print(", ".join(valid_pairs))