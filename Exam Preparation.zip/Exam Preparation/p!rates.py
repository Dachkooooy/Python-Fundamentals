cities = {}

while (command:= input()) != "Sail":
    city, population, gold = command.split("||")
    population = int(population)
    gold = int(gold)
    if city not in cities.keys():
        cities[city] = {"population": 0, "gold": 0}
    cities[city]["population"] += int(population)
    cities[city]["gold"] += int(gold)

event = input().split("=>")
while event[0] != "End":
    if event[0] == "Plunder":
        town, people, gold = event[1], int(event[2]), int(event[3])
        print(f"{town} plundered! {gold} gold stolen, {people} citizens killed.")
        cities[town]["population"] -= people
        cities[town]["gold"] -= gold
        if cities[town]["population"] == 0 or cities[town]["gold"] == 0:
            cities.pop(town)
            print(f"{town} has been wiped off the map!")

    elif event[0] == "Prosper":
        town, gold = event[1], int(event[2])
        if gold < 0:
            print(f"Gold added cannot be a negative number!")
        else:
            cities[town]["gold"] += gold
            total_gold = cities[town]["gold"]
            print(f"{gold} gold added to the city treasury. {town} now has {total_gold} gold.")

    event = input().split("=>")

if cities:
    print(f"Ahoy, Captain! There are {len(cities)} wealthy settlements to go to:")
    for town, data in cities.items():
        print(f"{town} -> Population: {data['population']} citizens, Gold: {data['gold']} kg")
else:
    print("Ahoy, Captain! All targets have been plundered and destroyed!")