import re

some_places = input()
pattern = r"([=\/])([A-Z]{1}[A-Za-z]{2,})\1"
matches = re.finditer(pattern, some_places)
total_points = 0
valid_places = []

if matches:
    for match in matches:
        valid_places.append(match.group(2))
        total_points += len(match.group(2))
print(f"Destinations: {', '.join(valid_places)}")
print(f"Travel Points: {total_points}")
