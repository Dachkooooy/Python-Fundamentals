def add_stop(stops_string: str, some_index: int, some_substring) -> str:
    if some_index in range(len(stops_string)):
        stops_string = stops_string[:some_index] + some_substring + stops_string[some_index:]
    return stops_string


def remove_stop(stops_string: str, starting_index: int, ending_index: int) -> str:
    if starting_index in range(len(stops_string)) and ending_index in range(len(stops_string)):
        stops_string = stops_string[:starting_index] + stops_string[ending_index + 1:]
    return stops_string


def switch(stops_string, some_old_string, some_new_string) -> str:
    if some_old_string in stops_string:
        stops_string = stops_string.replace(some_old_string, some_new_string)
    return stops_string


stops = input()
command = input().split(":")
while command[0] != "Travel":

    if command[0] == "Add Stop":
        index, substring = int(command[1]), command[2]
        stops = add_stop(stops, index, substring)
    elif command[0] == "Remove Stop":
        start_index, end_index = int(command[1]), int(command[2])
        stops = remove_stop(stops, start_index, end_index)
    elif command[0] == "Switch":
        old_string, new_string = command[1], command[2]
        stops = switch(stops, old_string, new_string)
    print(stops)
    command = input().split(":")

print(f"Ready for world tour! Planned stops: {stops}")
