secret_message = input()
deleted_substring = ''
while (command:= input()) != "Reveal":
    command = command.split(":|:")

    if command[0] == "InsertSpace":
        index = int(command[1])
        secret_message = secret_message[:index] + " " + secret_message[index:]
        print(secret_message)

    elif command[0] == "Reverse":
        substring = command[1]
        if substring in secret_message:
            for string in substring:
                deleted_substring += string
            secret_message = secret_message.replace(substring, "")
            secret_message += deleted_substring[::-1]
            print(secret_message)
        else:
            print("error")

    elif command[0] == "ChangeAll":
        substring = command[1]
        replacement = command[2]
        if substring in secret_message:
            secret_message = secret_message.replace(substring, replacement)
            print(secret_message)

print(f"You have a new text message: {secret_message}")
