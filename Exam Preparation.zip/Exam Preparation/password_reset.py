string = input()
new_pass = string

while (command := input()) != "Done":
    command = command.split()

    if command[0] == "TakeOdd":
        new_pass = ''.join([new_pass[i] for i in range(len(new_pass)) if i % 2 != 0])
        print(new_pass)

    elif command[0] == "Cut":
        index = int(command[1])
        length = int(command[2])
        new_pass = new_pass[:index] + new_pass[index + length:]
        print(new_pass)

    elif command[0] == "Substitute":
        substring, substitute = command[1], command[2]
        if substring in new_pass:
            new_pass = new_pass.replace(substring, substitute)
            print(new_pass)
        else:
            print("Nothing to replace!")

print(f"Your password is: {new_pass}")
