import re

some_text = input()
pattern = r"(?P<delim>::|\*\*)([A-Z][a-z]{2,})\1"
matches = re.finditer(pattern, some_text)
cool_threshold = 1
cool_list = []
all_emojis = []

for digit in some_text:
    if digit.isdigit():
        cool_threshold *= int(digit)

for match in matches:
    coolness = sum(ord(char) for char in match.group(2))
    if coolness > cool_threshold:
        cool_list.append(match.group(0))
    all_emojis.append(match.group(0))

print(f"Cool threshold: {cool_threshold}")
print(f"{len(all_emojis)} emojis found in the text. The cool ones are:")
print("\n".join(cool_list))
