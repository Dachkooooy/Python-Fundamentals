import re

number = int(input())
pattern = r"@#+([A-Z][A-Za-z0-9]{4,}[A-Z])@#+"

for _ in range(number):
    barcode = input()
    match = re.match(pattern, barcode)
    if match:
        core = match.group(1)
        product_group = ''.join(filter(str.isdigit, core)) or '00'
        print(f"Product group: {product_group}")
    else:
        print("Invalid barcode")