number_of_heroes = int(input())
heroes = {}
max_hit_points = 100
max_mana_points = 200

for _ in range(number_of_heroes):
    hero_name, hit_points, mana_points = input().split()
    heroes[hero_name] = {'hit_points': int(hit_points), 'mana_points': int(mana_points)}

while (command:= input()) != "End":
    command = command.split(" - ")

    if command[0] == "CastSpell":
        hero_name = command[1]
        mp_needed = int(command[2])
        spell_name = command[3]
        if mp_needed <= heroes[hero_name]['mana_points']:
            heroes[hero_name]['mana_points'] -= mp_needed
            print(f"{hero_name} has successfully cast {spell_name} and now has {heroes[hero_name]['mana_points']} MP!")
        else:
            print(f"{hero_name} does not have enough MP to cast {spell_name}!")

    elif command[0] == "TakeDamage":
        hero_name = command[1]
        damage = int(command[2])
        attacker = command[3]
        heroes[hero_name]['hit_points'] -= damage
        if heroes[hero_name]['hit_points'] > 0:
            print(f"{hero_name} was hit for {damage} HP by {attacker} and now has {heroes[hero_name]['hit_points']} HP left!")
        else:
            print(f"{hero_name} has been killed by {attacker}!")
            heroes.pop(hero_name)

    elif command[0] == "Recharge":
        hero_name = command[1]
        mana_amount = int(command[2])
        heroes[hero_name]['mana_points'] += mana_amount
        if heroes[hero_name]['mana_points'] > max_mana_points:
            exceeding_recharge = heroes[hero_name]['mana_points'] - max_mana_points
            mana_amount -= exceeding_recharge
            heroes[hero_name]['mana_points'] = max_mana_points
        print(f"{hero_name} recharged for {mana_amount} MP!")

    elif command[0] == "Heal":
        hero_name = command[1]
        hit_amount = int(command[2])
        heroes[hero_name]['hit_points'] += hit_amount
        if heroes[hero_name]['hit_points'] > max_hit_points:
            exceeding_heal = heroes[hero_name]['hit_points'] - max_hit_points
            hit_amount -= exceeding_heal
            heroes[hero_name]['hit_points'] = max_hit_points
        print(f"{hero_name} healed for {hit_amount} HP!")

for hero, data in heroes.items():
    print(f"{hero}\n  HP: {data['hit_points']}\n  MP: {data['mana_points']}")