some_number = int(input())
plant_dictionary = {}

for _ in range(some_number):
    discovery = input().split("<->")
    plant, rarity = discovery[0], int(discovery[1])
    if plant not in plant_dictionary:
        plant_dictionary[plant] = {'rarity': rarity, 'ratings': []}
    else:
        plant_dictionary[plant]['rarity'] = rarity  # update rarity if plant already exists

while (command := input()) != "Exhibition":
    action, details = command.split(": ")
    if action == "Rate":
        plant, rating = details.split(" - ")
        if plant in plant_dictionary:
            plant_dictionary[plant]['ratings'].append(float(rating))
        else:
            print("error")
    elif action == "Update":
        plant, new_rarity = details.split(" - ")
        if plant in plant_dictionary:
            plant_dictionary[plant]['rarity'] = int(new_rarity)
        else:
            print("error")
    elif action == "Reset":
        plant = details
        if plant in plant_dictionary:
            plant_dictionary[plant]['ratings'] = []
        else:
            print("error")
    else:
        print("error")

print("Plants for the exhibition:")
for plant, data in plant_dictionary.items():
    avg_rating = sum(data['ratings']) / len(data['ratings']) if data['ratings'] else 0
    print(f"- {plant}; Rarity: {data['rarity']}; Rating: {avg_rating:.2f}")
