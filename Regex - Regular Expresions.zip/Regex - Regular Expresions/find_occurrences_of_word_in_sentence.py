import re

sentence = input()
searched_word = input()
pattern = fr"\b{searched_word}\b"
occurrences = re.findall(pattern, sentence, re.IGNORECASE)
# second solution using a regex flag
# pattern = fr"(?i)\b{searched_word}\b"
# occurrences = re.findall(pattern, sentence)

print(len(occurrences))