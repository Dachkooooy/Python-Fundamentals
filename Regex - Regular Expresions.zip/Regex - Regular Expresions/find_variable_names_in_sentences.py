import re

sentences = input()
pattern = r"\b_([A-Za-z0-9]+)\b"
variable_names = re.findall(pattern, sentences)

print(",".join(variable_names))