import re

pattern = r">>([A-Za-z]+)<<(\d+\.?\d*)!(\d+)"
total_cost = 0
bought_furniture = []
furniture = input()
while furniture != 'Purchase':
    match = re.search(pattern, furniture)
    if match:
        items, price, quantity = match.groups()
        bought_furniture.append(items)
        total_cost += float(price) * int(quantity)
    furniture = input()

print("Bought furniture:")
for item in bought_furniture:
    print(item)
print(f"Total money spend: {total_cost:.2f}")
