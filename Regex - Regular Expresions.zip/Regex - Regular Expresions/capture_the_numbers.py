import re
all_matches = []
line = input()
while line:
    pattern = r"\d+"
    matches = re.findall(pattern, line)
    if matches: # if len(matches) > 0:
        all_matches += matches
    line = input()

print(" ".join(all_matches), end= " ")