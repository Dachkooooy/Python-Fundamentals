# Python_Fundamentals
Learning Python - testing skills and building fundamental foundation through excercises. 
