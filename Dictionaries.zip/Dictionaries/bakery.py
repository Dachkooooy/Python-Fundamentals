elements = input().split()
bakery = {}
for element in range(0, len(elements), 2):
    food = elements[element]
    quantities = elements[element + 1]
    bakery[food] = int(quantities)

print(bakery)
