materials = {"shards": 0, 'fragments': 0, 'motes': 0}
have_legendary_item = False

while not have_legendary_item:
    item_received = input().split()
    for index in range(0, len(item_received), 2):
        quantity = int(item_received[index])
        material = item_received[index + 1].lower()
        if material not in materials.keys():
            materials[material] = 0
        materials[material] += quantity
        if materials["shards"] >= 250:
            materials["shards"] -= 250
            print("Shadowmourne obtained!")
            have_legendary_item = True

        elif materials["fragments"] >= 250:
            materials["fragments"] -= 250
            print("Valanyr obtained!")
            have_legendary_item = True

        elif materials["motes"] >= 250:
            materials["motes"] -= 250
            print("Dragonwrath obtained!")
            have_legendary_item = True

        if have_legendary_item:
            break
for material, quantity in materials.items():
    print(f"{material}: {quantity}")

