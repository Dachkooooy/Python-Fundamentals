submissions_dictionary = {}
ranking_dictionary = {}

while (submission := input()) != "end of contests":
    contest, password_for_contest = submission.split(":")
    submissions_dictionary[contest] = password_for_contest

while (command := input()) != "end of submissions":
    contest_, password_, username_, points_ = command.split("=>")
    points_ = int(points_)

    if contest_ in submissions_dictionary and submissions_dictionary[contest_] == password_:
        if username_ not in ranking_dictionary:
            ranking_dictionary[username_] = {}
        if contest_ not in ranking_dictionary[username_] or ranking_dictionary[username_][contest_] < points_:
            ranking_dictionary[username_][contest_] = points_

best_user = ""
max_points = 0

for user, contests in ranking_dictionary.items():
    total_points = sum(contests.values())
    if total_points > max_points:
        best_user = user
        max_points = total_points

print(f"Best candidate is {best_user} with total {max_points} points.")
print("Ranking:")

for user in sorted(ranking_dictionary):
    print(user)
    for contest, points in sorted(ranking_dictionary[user].items(), key=lambda x: -x[1]):
        print(f"#  {contest} -> {points}")
