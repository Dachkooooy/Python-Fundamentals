from collections import defaultdict

exam_results = {}
submission_counts = defaultdict(int)

while (command := input()) != 'exam finished':
    parts = command.split("-")

    if parts[1] == "banned":
        username = parts[0]
        exam_results.pop(username, None)
        continue

    username, language, points = parts[0], parts[1], int(parts[2])
    submission_counts[language] += 1

    if username not in exam_results:
        exam_results[username] = {'points': points}
    else:
        exam_results[username]['points'] = max(exam_results[username]['points'], points)

print("Results:")
for username, data in exam_results.items():
    print(f"{username} | {data['points']}")

print("Submissions:")
for language, count in submission_counts.items():
    print(f"{language} - {count}")



# exam_results = {}
# count_of_submissions = {}
# languages = []
#
# while (command:= input()) != 'exam finished':
#     command = command.split("-")
#     if command[1] == "banned":
#         username = command[0]
#         if username in exam_results.keys():
#             for current in exam_results[username]['language']:
#                 languages.append(current)
#             exam_results.pop(username)
#             continue
#
#     username = command[0]
#     language = command[1]
#     points = command[2]
#
#     if username not in exam_results:
#         exam_results[username] = {'language': [], 'points': int(points)}
#         exam_results[username]['language'].append(language)
#     else:
#         if language in exam_results[username]['language']:
#             if exam_results[username]['points'] < int(points):
#                 exam_results[username]['points'] = int(points)
#         else:
#             exam_results[username]['language'].append(language)
#             exam_results[username]['points'] += int(points)
#
#     for user in exam_results.keys():
#         for current in exam_results[user]['language']:
#             languages.append(current)
#
# print(f"Results:")
# for username, data in exam_results.items():
#     print(f"{username} | {data['points']}")
#
# submissions = {}
# for lang in languages:
#     if lang not in submissions.keys():
#         submissions[lang] = 1
#     else:
#         submissions[lang] += 1
# print("Submissions:")
# for submission in submissions:
#     print(f"{submission} - {submissions[submission]}")


