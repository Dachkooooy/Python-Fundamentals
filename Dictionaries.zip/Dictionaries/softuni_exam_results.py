exam_results = {}
count_of_submissions = {}
while True:
    command = input()
    if command == 'exam finished':
        break

    if "banned" in command:
        username, is_banned = command.split("-")
        if username in exam_results.keys():
            exam_results.pop(username)
            continue

    username, language, points = command.split("-")

    if username not in exam_results:
        exam_results[username] = []
    if language not in exam_results[username]:
        exam_results[username].append(language)
        exam_results[username].append(points)
        if language not in count_of_submissions.keys():
            count_of_submissions[language] = 0
    count_of_submissions[language] += 1
    if points > exam_results[username][-1]:
        exam_results[username][-1] = points

print(f"Results:")
for username in exam_results.keys():
    print(f"{username} | {exam_results[username][-1]}")
print("Submissions:")
for language in count_of_submissions.keys():
    print(f"{language} - {count_of_submissions[language]}")


