academy = {}
number_of_students = int(input())
counter_per_student = {}

for _ in range(number_of_students):
    student_name = input()
    grade = float(input())

    if student_name not in academy:
        academy[student_name] = 0
        counter_per_student[student_name] = 0
    academy[student_name] += grade
    counter_per_student[student_name] += 1

    average_grades = {
        student_name: academy[student_name] / counter_per_student[student_name]
        for student_name in academy
        if academy[student_name] / counter_per_student[student_name] >= 4.5
    }

for student_name, avg_grade in average_grades.items():
    print(f"{student_name} -> {avg_grade:.2f}")



