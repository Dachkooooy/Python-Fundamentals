phonebook_dictionary = {}

while True:
    phonebook = input()
    if "-" not in phonebook:
        break

    name, number = phonebook.split("-")
    phonebook_dictionary[name] = number

searches = int(phonebook)
for _ in range(searches):
    search_name = input()
    if search_name in phonebook_dictionary.keys():
        print(f"{search_name} -> {phonebook_dictionary[search_name]}")
    else:
        print(f"Contact {search_name} does not exist.")
