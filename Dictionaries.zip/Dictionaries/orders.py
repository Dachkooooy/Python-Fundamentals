orders_dictionary = {}
while True:
    command = input()
    if command == "buy":
        break
    product_name, price, quantity = command.split()


    if product_name not in orders_dictionary.keys():
        orders_dictionary[product_name] = [0.0, 0]
    orders_dictionary[product_name][1] += int(quantity)
    if orders_dictionary[product_name][0] != float(price):
        orders_dictionary[product_name][0] = float(price)

for product_name in orders_dictionary:
    total_price = float(orders_dictionary[product_name][0]) * int(orders_dictionary[product_name][1])
    print(f"{product_name} -> {total_price:.2f}")

