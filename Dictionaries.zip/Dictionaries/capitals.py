country = input().split(", ")
capitals = input().split(", ")

# pair_of_country_and_capitals = {country[index]:capitals[index] for index in range(len(country))}
pair_of_country_and_capitals = dict(zip(country, capitals))
for country, capital in pair_of_country_and_capitals.items():
    print(f"{country} -> {capital}")



