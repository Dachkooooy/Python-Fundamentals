resources = {}

while (command:= input()) != "stop":
    quantity = int(input())
    if command not in resources.keys():
        resources[command] = 0
    resources[command] += quantity

for resource, quantity in resources.items():
    print(f"{resource} -> {quantity}")