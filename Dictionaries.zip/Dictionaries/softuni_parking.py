people_to_validate = int(input())
parking = {}
for person in range(people_to_validate):
    current_person = input().split()
    if current_person[0] == "register":
        username, license_plate_number = current_person[1], current_person[2]
        if username in parking.keys():
            print(f"ERROR: already registered with plate number {license_plate_number}")
        else:
            parking[username] = license_plate_number
            print(f"{username} registered {license_plate_number} successfully")
    elif current_person[0] == "unregister":
        username = current_person[1]
        if username not in parking.keys():
            print(f"ERROR: user {username} not found")
        else:
            del parking[username]
            print(f"{username} unregistered successfully")

for username, license_plate_number in parking.items():
    print(f"{username} => {license_plate_number}")


